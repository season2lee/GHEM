-- --------------------------------------------------------
-- 호스트:                          j8d107.p.ssafy.io
-- 서버 버전:                        8.0.32 - MySQL Community Server - GPL
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- ghem 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `ghem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `ghem`;

-- 테이블 ghem.cpu 구조 내보내기
CREATE TABLE IF NOT EXISTS `cpu` (
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `part_number` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `model` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ranking` int DEFAULT NULL,
  `benchmark` int DEFAULT NULL,
  `samples` int DEFAULT NULL,
  `url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id` int NOT NULL,
  `prat_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.game 구조 내보내기
CREATE TABLE IF NOT EXISTS `game` (
  `app_id` bigint NOT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `negative_reviews` int NOT NULL,
  `positive_reviews` int NOT NULL,
  `rating` int NOT NULL,
  `rating_desc` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `release_date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.genres 구조 내보내기
CREATE TABLE IF NOT EXISTS `genres` (
  `genre_id` int NOT NULL,
  `genre` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.gpu 구조 내보내기
CREATE TABLE IF NOT EXISTS `gpu` (
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `part_number` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `model` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ranking` int DEFAULT NULL,
  `benchmark` int DEFAULT NULL,
  `samples` int DEFAULT NULL,
  `url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `id` int NOT NULL,
  `prat_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.helpful 구조 내보내기
CREATE TABLE IF NOT EXISTS `helpful` (
  `helpful_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `user_game_id` bigint DEFAULT NULL,
  PRIMARY KEY (`helpful_id`),
  KEY `FKb8yx0ap93gpsoenisokkupody` (`user_game_id`),
  CONSTRAINT `FKb8yx0ap93gpsoenisokkupody` FOREIGN KEY (`user_game_id`) REFERENCES `usergame` (`user_game_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.hibernate_sequence 구조 내보내기
CREATE TABLE IF NOT EXISTS `hibernate_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.usergame 구조 내보내기
CREATE TABLE IF NOT EXISTS `usergame` (
  `user_game_id` bigint NOT NULL,
  `rating` int NOT NULL,
  `app_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `helpful` int DEFAULT NULL,
  PRIMARY KEY (`user_game_id`),
  KEY `FK52gk61jy3yldvw4a5lj5gc89e` (`app_id`),
  KEY `FKfso4thtuhy7g1gjue2m2tvgah` (`user_id`),
  CONSTRAINT `FK52gk61jy3yldvw4a5lj5gc89e` FOREIGN KEY (`app_id`) REFERENCES `game` (`app_id`),
  CONSTRAINT `FKfso4thtuhy7g1gjue2m2tvgah` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 ghem.users 구조 내보내기
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` bigint NOT NULL,
  `birth` varchar(255) DEFAULT NULL,
  `gender` int NOT NULL,
  `id` varchar(255) DEFAULT NULL,
  `introduce` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `steamId` varchar(255) DEFAULT NULL,
  `userProfile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
